#!/bin/bash

ls Makefile && make clean
find . | grep -i '\./cmake' | xargs rm -rf
cmake -DCMAKE_BUILD_TYPE=Debug -DCMAKE_DEBUG_POSTFIX=d -DCMAKE_C_COMPILER="clang" -DCMAKE_CXX_COMPILER="clang++" -DCMAKE_CXX_FLAGS="-std=c++11 -stdlib=libc++" ../../../IntegrationTests
 
