#!/bin/bash

ls Makefile && make clean
find . | grep -i '\./cmake' | xargs rm -rf
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER="clang" -DCMAKE_CXX_COMPILER="clang++" -DCMAKE_CXX_FLAGS="-std=c++11 -stdlib=libc++" ../../../UnitTests
 
